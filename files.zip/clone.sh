#!/usr/bin/env bash
# Uso: ./clone.sh <alias> <repo>
#   <repo> pode ser: URL completa, owner/repo ou apenas repo (usa o owner do alias)
# Ex.:  ./clone.sh mdelapi https://github.com/mdelapi/sampleone
#       ./clone.sh mdelapi mdelapi/sampleone
#       ./clone.sh mdelapi sampleone
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ $# -lt 2 ]; then
  echo "Uso: $0 <alias> <repo>" >&2; exit 1
fi

ALIAS="$1"; REPO="$2"

# shellcheck disable=SC1091
. "$ROOT/ghuse.sh" "$ALIAS"

# normaliza para owner/repo
REPO="${REPO#https://github.com/}"
REPO="${REPO#http://github.com/}"
REPO="${REPO#git@github.com:}"
REPO="${REPO%.git}"
REPO="${REPO%/}"
case "$REPO" in */*) ;; *) REPO="$GH_USER/$REPO" ;; esac

NAME="${REPO##*/}"
DEST="$GH_WORKDIR/$NAME"

# transporte: SSH se houver chave, senão HTTPS
if [ -n "$GH_SSH_KEY" ]; then
  URL="git@github.com:$REPO.git"
else
  URL="https://github.com/$REPO.git"
fi

if [ -d "$DEST/.git" ]; then
  echo "[clone] já existe: $DEST -> git pull"
  git -C "$DEST" pull --ff-only
else
  echo "[clone] $URL -> $DEST"
  git clone "$URL" "$DEST"
fi

# identidade/chave gravadas no repo, para add/commit/push funcionarem
# mesmo sem dar "source ghuse.sh" de novo
git -C "$DEST" config user.name  "$GH_NAME"
git -C "$DEST" config user.email "$GH_EMAIL"
if [ -n "$GH_SSH_KEY" ]; then
  git -C "$DEST" config core.sshCommand "ssh -i $GH_SSH_KEY -o IdentitiesOnly=yes"
fi

echo
echo "Pronto. Para trabalhar:"
echo "  cd $DEST"
echo "  git add . && git commit -m \"mensagem\" && git push"
